#include <iostream>
using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");
    int n, A[100];
    cout << "n: ";
    cin >> n;

    cout << "��������: ";
    for (int i = 0; i < n; i++) cin >> A[i];

    int pos = 0;
    for (int i = 0; i < n; i++) {
        if (A[i] != 0) {
            A[pos++] = A[i];
        }
    }

    for (int i = pos; i < n; i++) {
        A[i] = 0;
    }

    cout << "���������: ";
    for (int i = 0; i < n; i++) cout << A[i] << " ";
    cout << endl;

    return 0;
}