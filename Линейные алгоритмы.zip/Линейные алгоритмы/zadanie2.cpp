#include <iostream>
using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");
    double rad;
    cout << "�������: ";
    cin >> rad;

    double deg = rad * 180.0 / 3.14159265;
    int g = (int)deg;

    double min_frac = (deg - g) * 60;
    int m = (int)min_frac;

    double sec_frac = (min_frac - m) * 60;
    int s = (int)(sec_frac + 0.5);

    if (s >= 60) {
        s = 0;
        m++;
    }
    if (m >= 60) {
        m = 0;
        g++;
    }

    cout << "�������: " << g << "� " << m << "' " << s << "''" << endl;
    return 0;
}