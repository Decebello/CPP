#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    setlocale(LC_ALL, "Russian");
    double max_km;
    cout << "���� ���������� � ��: ";
    cin >> max_km;

    cout << fixed << setprecision(4);
    cout << "\n����\t��" << endl;

    for (double miles = 0; miles * 1.609 <= max_km; miles += 0.6214) {
        double km = miles * 1.609;
        cout << miles << "\t" << km << endl;
    }

    cout << "\n��\t����" << endl;
    for (double km = 0; km <= max_km; km++) {
        double miles = km * 0.6214;
        cout << km << "\t" << miles << endl;
    }

    return 0;
}