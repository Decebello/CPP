#include <iostream>
using namespace std;

int divs(int N, int div = 2) {
    if (div >= N) {
        return 0;
    }

    if (N % div == 0) {
        return 1 + divs(N, div + 1);
    }

    else {
        return divs(N, div + 1);
    }
}

int main() {
    cout << "divs(5) = " << divs(5) << endl;
    cout << "divs(18) = " << divs(18) << endl;

    return 0;
}