#include <iostream>
using namespace std;

bool equal(int N, int S) {
    if (N == 0) {
        return S == 0;
    }

    if (S < 0) {
        return false;
    }

    return equal(N / 10, S - (N % 10));
}

int main() {
    setlocale(LC_ALL, "Russian");

    cout << "equal(12345, 15) = " << (equal(12345, 15) ? "True" : "False") << endl;
    cout << "equal(24, 7) = " << (equal(24, 7) ? "True" : "False") << endl;
    cout << "equal(100, 1) = " << (equal(100, 1) ? "True" : "False") << endl;

    return 0;
}